//
//  RegistViewController.h
//  ParentStar
//
//  Created by WWJ on 2019/12/16.
//  Copyright © 2019年 Socrates. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RegistViewController : UIViewController
@property (nonatomic, assign) BOOL isPhone;
@property (nonatomic, strong) NSDictionary *dic;


@end

NS_ASSUME_NONNULL_END
