//
//  ForgetPwdViewController.h
//  ParentStar
//
//  Created by WWJ on 2019/12/17.
//  Copyright © 2019 Socrates. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ForgetPwdViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
