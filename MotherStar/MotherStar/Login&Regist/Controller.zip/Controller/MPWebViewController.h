//
//  MPWebViewController.h
//  MotherStar
//
//  Created by 王文杰 on 2020/1/8.
//  Copyright © 2020 yanming niu. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface MPWebViewController : BaseViewController
@property (nonatomic,copy) NSString *url;
@end

NS_ASSUME_NONNULL_END
